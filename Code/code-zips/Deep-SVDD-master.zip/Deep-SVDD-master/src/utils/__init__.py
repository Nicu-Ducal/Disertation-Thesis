from config import Configuration

config_ = Configuration()