implemented_datasets = ('mnist', 'cifar10', 'gtsrb')
